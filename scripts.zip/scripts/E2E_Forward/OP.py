import streamlit as st
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
import tensorflow as tf
from tensorflow import keras

def actual_trss(n1,n2,height,radius,gap):
    df = pd.read_csv('Ag_3_reduced.csv',low_memory=False)

    if int(radius) % 2 == 0:
        radius = int(radius-1)
    else:
        radius= int(radius)

    if int(gap) % 2 == 0:
        gap = int(gap-1)
    else:
        gap = int(gap)

    filtered_df = df[(df['n2'] == n2) & (df['rad'] == radius) & (df['gap'] == gap)]
    result_values = filtered_df['Ts']

    return result_values


def predict_trss(n1, n2, height, radius, gap):
    
    a = (radius-27.176199438026963)/13.17202192625192
    b = (gap - 54.1006631715935)/36.07597465176819
    c = (n2-3.699815690207628)/0.3997656731778045
    start_value = 400
    end_value = 1001
    data = []

    for i in range(start_value, end_value,2):
        data.append([a,b,c,i])
    for i in range(0,301):
        data[i][3] = (data[i][3]-700.0102603338136)/173.78230000960846
    X = pd.DataFrame(data)
    loaded_model = tf.keras.models.load_model("regression-model-epoch-500-scaled.h5", compile = False)
    new_predictions = loaded_model.predict(X)

    return new_predictions


logo_image = "IITG_logo.png" 
    #st.image(logo_image, use_column_width=True)
    #st.sidebar.image(logo_image, use_container_width=True)
st.image(logo_image, width=150, output_format="PNG", caption="NaPaMegs")

st.title("TRS Value Prediction")

    # User Inputs
n2 = st.number_input("Enter n2 value (3 - 4)", min_value=3.0, max_value=4.5, step=0.1,value = 4.1)
n1 = st.selectbox("Select n1 value", [1.58])
height = 0.0
radius = st.number_input("Select radius value (5 - 50 nm)", min_value=5.0, max_value=50.0, step=2.0)
gap = st.number_input("Select gap value (3 - 120 nm)", min_value=3.0, max_value=120.0,step=2.0)



predicted_trs = predict_trss(n1, n2, height, radius, gap)
actual_trs = actual_trss(n1,n2,height,radius,gap)

plt.figure(figsize=(10, 6))
plt.plot(range(301),predicted_trs, label="Predicted TRS")
plt.plot(range(301),actual_trs, label="Actual TRS")
plt.xlabel("Sample")
plt.ylabel("TRS Value")
plt.title("Actual TRS vs Predicted TRS")
plt.legend()
st.pyplot(plt)

