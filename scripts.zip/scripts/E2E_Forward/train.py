import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import tensorflow as tf
from sklearn.model_selection import train_test_split, KFold
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_absolute_error, r2_score
from tensorflow.keras.layers import Dense, LeakyReLU
from tensorflow.keras.models import Sequential
from tensorflow.keras.optimizers import Adam

# Check GPU Availability
gpus = tf.config.experimental.list_physical_devices('GPU')
if gpus:
    try:
        for gpu in gpus:
            tf.config.experimental.set_memory_growth(gpu, True)
        print(f"{len(gpus)} GPU(s) available.")
    except RuntimeError as e:
        print(e)
else:
    print("No GPU available. Using CPU.")

# Load Dataset
data = pd.read_csv('/scratch/napamegs/Ag_height0/Ag_3_reduced.csv')

# Data Preprocessing
input_cols = ['rad', 'gap', 'n2', 'lambda_val']
output_col = ['Ts']
X = data[input_cols]
y = data[output_col]
scaler = StandardScaler()

# K-Fold Cross Validation
kfold = KFold(n_splits=5, shuffle=True, random_state=42)

fold_no = 1
loss_per_fold = []
mae_per_fold = []
r2_per_fold = []

for train, test in kfold.split(X, y):
    X_train, X_test = X.iloc[train], X.iloc[test]
    y_train, y_test = y.iloc[train], y.iloc[test]
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)

    # Model Definition
    model = Sequential([
        Dense(64, input_shape=(4,)),
        LeakyReLU(alpha=0.1),
        Dense(128),
        LeakyReLU(alpha=0.1),
        Dense(128),
        LeakyReLU(alpha=0.1),
        Dense(64),
        LeakyReLU(alpha=0.1),
        Dense(1, activation='linear')
    ])

    model.compile(loss='mean_squared_error', optimizer=Adam(), metrics=['mse', 'mae'])

    # Training
    print(f'Training for fold {fold_no} ...')
    history = model.fit(X_train_scaled, y_train, epochs=50, batch_size=2000, validation_data=(X_test_scaled, y_test))

    # Evaluating the model
    scores = model.evaluate(X_test_scaled, y_test, verbose=0)
    predictions = model.predict(X_test_scaled)
    r2 = r2_score(y_test, predictions)
    
    print(f'Score for fold {fold_no}: {model.metrics_names[0]} of {scores[0]}; {model.metrics_names[1]} of {scores[1]}')
    print("Loss",scores[0])
    print("MAE",scores[2])
    print("R2",r2)
    loss_per_fold.append(scores[0])
    mae_per_fold.append(scores[2])
    r2_per_fold.append(r2)

    fig, ax = plt.subplots(nrows=1, ncols=2, figsize=(12, 6))
    ax[0].plot(history.history['loss'], label='Train Loss')
    ax[0].set_title(f'Fold {fold_no} Train Loss')
    ax[0].set_xlabel('Epochs')
    ax[0].set_ylabel('Loss')
    ax[0].legend()

    ax[1].plot(history.history['val_loss'], label='Validation Loss')
    ax[1].set_title(f'Fold {fold_no} Validation Loss')
    ax[1].set_xlabel('Epochs')
    ax[1].set_ylabel('Loss')
    ax[1].legend()

    plt.tight_layout()
    plt.savefig(f"loss_fold_{fold_no}.png")
    plt.close()

    
    fold_no += 1
model.save('height-regression-fold-5-epochs-100.h')
print("Model training complete.")

print(mae_per_fold)
print(loss_per_fold)
print(r2_per_fold)
print(f'Average Loss: {np.mean(loss_per_fold)}')
print(f'Average MAE: {np.mean(mae_per_fold)}')
print(f'Average R^2 Score: {np.mean(r2_per_fold)}')
