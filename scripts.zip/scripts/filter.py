# import os
# import pandas as pd


# directory = '/scratch/napamegs/chunks_Ag3.1/'


# for filename in os.listdir(directory):
#     if filename.endswith(".csv"):
#         df = pd.read_csv(os.path.join(directory, filename))
        
#         df = df[(df['lambda_val'] >= 400) & (df['lambda_val'] <= 1000)]
        
#         df.to_csv(os.path.join(directory, filename), index=False)
#         print(f'{filename} has been filtered')



import os
import pandas as pd
import gzip

input_dir = '/scratch/napamegs/Ag_n3.1/'
output_dir = '/scratch/napamegs/chunks_Ag3.1/'
chunk_size = 1000000

# loop through each file in the input directory
for file in os.listdir(input_dir):
    if file == 'TRS_259.csv.gz' or file == 'TRS_388.csv.gz' or file == 'TRS_293.csv.gz' or file == 'TRS_724.csv.gz' or file == 'TRS_456.csv.gz' or file == 'TRS_203.csv.gz' or file == 'TRS_188.csv.gz' or file == 'TRS_771.csv.gz' or file == 'TRS_756.csv.gz' or file == 'TRS_518.csv.gz' or file == 'TRS_735.csv.gz' or file == 'TRS_679.csv.gz':
            
        # read the compressed csv file into a pandas dataframe
        with gzip.open(os.path.join(input_dir, file), 'rt') as f:
            df = pd.read_csv(f)

        chunks = [df[i:i+chunk_size] for i in range(0, df.shape[0], chunk_size)]
        
        # write each chunk to a separate csv file in the output directory
        for i, chunk in enumerate(chunks):
            chunk_filename = f"chunk{i}_{file[:-3]}"
            chunk_path = os.path.join(output_dir, chunk_filename)
            chunk.to_csv(chunk_path, index=False)
