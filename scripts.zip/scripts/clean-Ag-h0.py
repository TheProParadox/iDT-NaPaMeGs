#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd


# In[2]:


df = pd.read_csv("/scratch/napamegs/Ag_height0/Ag_3_final.csv",low_memory='false')


df


# In[3]:


df['n1'].unique()


# In[4]:


df.dtypes


# In[5]:


df = df[df['n1'] != '1.58']


# In[6]:


df


# In[7]:


df = df[df['n1'] != 'n1']


# In[8]:


for i in ['n1','n2','height','rad','gap','lambda_val']:
    df[i] = df[i].astype('float64')


# In[9]:


df


# In[10]:


def radius_change(value):
    if value <= 50 and value % 2 == 1:
        return int(value)
    return None

df['rad'] = df['rad'].apply(radius_change)

df.dropna(subset=['rad'], inplace=True)
df = df.astype({'rad': 'int64'})

print("Radius cleaning complete")


# In[11]:


df


# In[12]:


def gap_change(value):
    if value >= 20 and value<=120 and value % 2 == 1:
        return int(value)
    elif value <=20:
        return int(value)
    else:
        return None


df['gap'] = df['gap'].apply(gap_change)

df.dropna(subset=['gap'], inplace=True)

df['gap'].unique()
df = df.astype({'gap': 'int64'})

print("Gap cleaning complete")


# In[13]:


def lambda_val_change(value):
    if value >= 400 and value<=1000:
        return int(value)
    else:
        return None

df['lambda_val'] = df['lambda_val'].apply(lambda_val_change)

df.dropna(subset=['lambda_val'], inplace=True)

df['lambda_val'].unique()
df = df.astype({'lambda_val': 'int64'})

print("Lambda cleaning complete")


# In[14]:


df


# In[15]:


print(df['n2'].unique())
print(df['n1'].unique())
print(df['rad'].unique())
print(df['gap'].unique())
print(df)


# In[16]:


df.reset_index()

df.to_csv('/scratch/napamegs/Ag_height0/Ag_3_reduced.csv')

print("Export to csv done")


# In[17]:


data = pd.read_csv('/scratch/napamegs/Ag_height0/Ag_3_reduced.csv')


# In[18]:


data


# In[19]:


data.dtypes


# In[20]:


data['isHex'].unique()


# In[21]:


def lambda_val_change(value):
    if value %2 == 0:
        return int(value)
    else:
        return None

data['lambda_val'] = data['lambda_val'].apply(lambda_val_change)

data.dropna(subset=['lambda_val'], inplace=True)

data['lambda_val'].unique()
data = data.astype({'lambda_val': 'int64'})

print("Lambda cleaning complete")


# In[22]:


data


# In[ ]:


data.reset_index()

data.to_csv('/scratch/napamegs/Ag_height0/Ag_3_reduced.csv')

print("Export to csv done")







