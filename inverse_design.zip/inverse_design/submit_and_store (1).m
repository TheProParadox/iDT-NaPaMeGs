cluster=parcluster();
numWorkers = 156;

job=batch(cluster,'Data_generation_code_1' ,'Pool',numWorkers-1,'CurrentFolder','/scratch/proj/napamegs/mat_out/theta/Au_n4.3'); %submit job







